package backup;
public class LaserProjectile 
{
	private double initial_laser_pos = -0.675;
	private double laser_y = initial_laser_pos;
	private double laser_velocity = 0;
	private boolean laser_is_in_motion = true;
	private double laser_x = 0;
	private double angle;
    

	public LaserProjectile(double refresh_rate, double x, double angle)
	{
		laser_velocity = 0.0032 * refresh_rate;
		laser_x = x;
		initial_laser_pos = -0.675;
		laser_y = initial_laser_pos;
		this.angle = angle;
	}

	public  void reset()
	{
		laser_y = initial_laser_pos;
	}

	public void increment_laser_pos(double angle) 
	{
		laser_y = laser_y + laser_velocity * Math.sin(Math.toRadians(angle));
		laser_x = laser_x + laser_velocity * Math.cos(Math.toRadians(angle));

		if (laser_y > 1 + 0.055 || laser_x > 1 + 0.055 || laser_x < -1 - 0.055)
		{
			laser_is_in_motion = false;
			this.reset();
		}
		else
		{
			laser_is_in_motion = true;
		}
	}
	

	public boolean draw_laser_beam(double x)
	{
		increment_laser_pos(angle);
		StdDrawModified.setPenColor(StdDrawModified.CYAN);
		if (!laser_is_in_motion)
		{
			laser_x = x;
		}
		
		// turn_laser();
		StdDrawModified.filledRectangle(laser_x, laser_y, 0.01, 0.050);
		return laser_is_in_motion;
	}
	
	public double get_laser_x()
	{
		return laser_x;
	}
	
	public double get_laser_y()
	{
		return laser_y;
	}
}