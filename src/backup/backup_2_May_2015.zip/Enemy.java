package backup;

public class Enemy {

	// Need to take in a coordinate for one enemy, 
	// and use Enemies to handle/manipulate the enemies i.e the Enemy class.
	public Enemy(float x, float y)
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
