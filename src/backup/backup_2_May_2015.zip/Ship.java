package backup;

public class Ship {
	
	private double ship_x;
	private double ship_y = -0.85;
	private double ship_width = 0.3;
	private double ship_height = 0.3;
	
	public Ship ()
	{
		
	}
	
	public void draw_spacecraft(double x, double angle)
	{
		this.ship_x = x;
		StdDrawModified.picture(ship_x,  ship_y,  "spacecraft.png", ship_width, ship_height, angle - 90.0);
	}
	
	public double get_x()
	{
		return ship_x;
	}
	
	public double get_y()
	{
		return ship_y;
	}
	
	public double get_ship_width()
	{
		return ship_width;
	}
	
	public double get_ship_height()
	{
		return ship_height;
	}

}
