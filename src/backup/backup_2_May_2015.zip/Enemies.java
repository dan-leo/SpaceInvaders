package backup;
import java.awt.Image;

public class Enemies {

	private double enemy_width = 0.35;
	private double enemy_height = 0.35;

	private double starting_x;
	private double starting_y;
	private boolean[] alive = new boolean[6];
	private int number_of_enemies;

	private double x_velocity;
	private double y_velocity;
	private boolean moving_horizontally = true;
	private double prev_starting_y;


	private double distance_between = 0.3;
	public Enemies(int nr_enemies, int index)
	{
		number_of_enemies = nr_enemies;
		for (int i = 0; i < number_of_enemies; i++)
		{
			alive[i] = true;
		}
		/*x_velocity = 0.01;
		y_velocity = 0.0075 / 2;*/
		x_velocity = 0.0075;
		y_velocity = 0.0065;
		set_starting_x(index);
		starting_y = 1 - (enemy_height/2);
		starting_y += index * enemy_height;

	}
	
	public boolean check_if_starting_y_lower_than_original_y()
	{
		if (starting_y <= 1 - enemy_height/2)
		{
			return true;
		}
		return false;
	}
	
	private void set_starting_x(int index)
	{
		double diff_between_min_max = max_starting_x() - min_starting_x();
		if (index % 2 == 0)
		{
			starting_x = (Math.random() * diff_between_min_max)/2 + min_starting_x();
		}
		else
		{
			starting_x = (Math.random() * diff_between_min_max)/2 + diff_between_min_max/2 + min_starting_x();
		}
	}
	
	private double max_starting_x()
	{
		return 1 - ((number_of_enemies - 1) * distance_between + enemy_width/2);
	}
	
	private double min_starting_x()
	{
		return -1 + enemy_width/2;
	}

	public boolean draw_enemies(Ship ship)
	{
		double temp_x = starting_x;
		double temp_y = starting_y;
		
		if (moving_horizontally)
		{
			prev_starting_y = starting_y;
			for (int i = 0; i < number_of_enemies; i++ ){
				if (alive[i])
				{
					Image image = StdDrawModified.getImage("spaceship.gif");
					// StdDrawModified.picture(temp_x + i * distance_between, temp_y, image, enemy_width, enemy_height, 0);
					StdDrawModified.picture(temp_x + i * distance_between, temp_y, "spaceship.gif", enemy_width, enemy_height);
				}
			}	
			starting_x += x_velocity;

			if (x_of_enemy(number_of_enemies - 1) + (enemy_width/2) > 1 || x_of_enemy(0) - (enemy_width/2) < -1)
			{
				x_velocity = -x_velocity;
				moving_horizontally = false;
			}
		}
		else
		{
			starting_y -= y_velocity;
			if (prev_starting_y - starting_y >= enemy_height)
			{
				moving_horizontally = true;
			}
			for (int i = 0; i < number_of_enemies; i++ ){
				if (alive[i])
				{
					StdDrawModified.picture(temp_x + i * distance_between, temp_y, "spaceship.gif", enemy_width, enemy_height);
				}
			}	

		}
		return check_ship_enemy_collision(ship);
	}
	
	public double get_y_velocity()
	{
		return y_velocity;
	}
	
	public void set_vertical_velocity(double y_velocity)
	{
		this.y_velocity = y_velocity;
	}
	
	public double get_x_velocity()
	{
		return x_velocity;
	}
	
	public void set_horizontal_velocity(double x_velocity)
	{
		if (this.x_velocity > 0)
		{
			this.x_velocity = x_velocity;
		}
		else
		{
			this.x_velocity = -x_velocity;
		}
	}

	public boolean check_for_collision(double laser_x, double laser_y)
	{
		for (int enemies_ct = 0; enemies_ct < number_of_enemies; enemies_ct++)
		{
			if (alive[enemies_ct])
			{
				if (laser_x > x_of_enemy(enemies_ct) - (distance_between/2) && laser_x < x_of_enemy(enemies_ct) + (distance_between/2))
				{
					if (laser_y > y_of_enemy(0) - (enemy_height/2) && laser_y < y_of_enemy(0) + (enemy_height/2))
					{
						alive[enemies_ct] = false;
						return true;
					}
				}
			}
		}
		return false;
	}

	private double x_of_enemy(int index)
	{
		return starting_x + distance_between * index;
	}

	private double y_of_enemy(int index)
	{
		return starting_y + distance_between * index;
	}

	public void reset(int index)
	{
		set_starting_x(index);
		starting_y = 1 - (enemy_height/2);
		starting_y += index * enemy_height;
		moving_horizontally = true;
		x_velocity = 0.01;
		y_velocity = 0.0075;
		for (int i = 0; i < number_of_enemies; i++)
		{
			alive[i] = true;
		}
	}

	private boolean check_ship_enemy_collision(Ship ship)
	{
		if (check_for_collision(ship.get_x() - ship.get_ship_width()/2, ship.get_y() + ship.get_ship_height()/2))
		{
			return true;
		}
		else if (check_for_collision(ship.get_x() + ship.get_ship_width()/2, ship.get_y() + ship.get_ship_height()/2))
		{
			return true;
		}
		for (int i = 0; i < number_of_enemies; i++)
		{
			if (alive[i])
			{
				if (starting_y - enemy_height/2 < -1)
				{
					return true;
				}
			}
		}
		return false;
	}

	public boolean all_dead()
	{
		for (int i = 0; i < number_of_enemies; i++)
		{
			if (alive[i])
			{
				return false;
			}
		}
		return true;
	}
	
	public boolean moving_downwards()
	{
		return !moving_horizontally;
	}
}
