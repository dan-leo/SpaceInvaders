package backup;
import java.util.TimerTask;

public class TimerClass extends TimerTask {

	private DeathStar mk2;
	
	@Override
	public void run()
	{
		update();
	}
	
	public TimerClass(DeathStar mk2) {
		this.mk2 = mk2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void update()
	{
		mk2.update_foreground();
		mk2.pressed_keys();
	}

}
