package backup;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


/**
 * Created by Daniel on 2015-03-01.
 */

public class DeathStar {

	// private variables
	private int FPS = 200;
	private int REFRESH_RATE_ms = 1000 / FPS; // 20 ms
	private double horiz_velocity = 0.0032 * REFRESH_RATE_ms;
	private double x = 0;

	private double max_x = 1.0;
	private double min_x = -1.0;
	private double max_y = 1.0;
	private double min_y = -1.0;

	private double angle = 90;
	private double angular_velocity = 0.5 * REFRESH_RATE_ms;
	private double max_angle = 180;
	private double min_angle = 0;

	private LaserProjectile missile;
	private Ship ship;
	private ArrayList<LaserProjectile> missiles;
	private ArrayList<Enemies> rows_of_enemies;

	private int canvas_x = 700;
	private int canvas_y = 650;

	private int level = 1;
	private long game_counter = 0;
	private long prev_reset_time = 0;

	private int total_rows_of_enemies = 5;
	private int total_columns_of_enemies = 5;

	private boolean game_over = false;
	
	private double vertical_velocity;
	private double horizontal_velocity;

	public DeathStar() {
		StdDrawModified.setCanvasSize(canvas_x, canvas_y);
		ship = new Ship();
		missiles = new ArrayList<LaserProjectile>();
		rows_of_enemies = new ArrayList<Enemies>();
		for (int i = 0; i < total_rows_of_enemies; i++)
		{
			rows_of_enemies.add(new Enemies(total_columns_of_enemies, i));
		}
		vertical_velocity = rows_of_enemies.get(0).get_y_velocity();
		horizontal_velocity = rows_of_enemies.get(0).get_x_velocity();
	}
     
	// setup runs once
	public void setup() {
		StdDrawModified.setXscale(min_x, max_x);
		StdDrawModified.setYscale(min_y, max_y);
		StdDrawModified.clear(StdDrawModified.DARK_GRAY);
		StdDrawModified.setPenColor(StdDrawModified.DARK_GRAY);
	}

	// draw enemies and return true if the game is over
	private boolean it_is_the_end()
	{
		for (int j = 0; j < rows_of_enemies.size(); j++)
		{
			if(rows_of_enemies.get(j).draw_enemies(ship))
			{
				return true;
			}
		}
		return false;
	}

	public void update_foreground() {

		/*
		 * if (System.currentTimeMillis() % 20 == 0) {}
		 */
		draw_all_enemies_and_lasers();
		vertical_velocity += 0.00001;
		horizontal_velocity += 0.00001;
		// System.out.println(horizontal_velocity + "   " + vertical_velocity);

		StdDrawModified.show(0);
		// System.out.println(game_counter);
	}
	
	public void move_left() {
		x -= horiz_velocity;
		if (x < min_x) {
			x = min_x;
		}
	}

	public void move_right() {
		x += horiz_velocity;
		if (x > max_x) {
			x = max_x;
		}
	}

	public void rotate_left() {
		angle += angular_velocity;
		if (angle > max_angle) {
			angle = max_angle;
		}
	}

	public void rotate_right() {
		angle -= angular_velocity;
		if (angle < min_angle) {
			angle = min_angle;
		}
	}

	/*
	 * public void process_key(char ch) { if (ch == 'q') { System.exit(0); } if
	 * (ch == 'a') { move_left(); } if (ch == 'd') { move_right(); } }
	 */

	public void pressed_keys() {
		if (StdDrawModified.isKeyPressed(KeyEvent.VK_Q)) {
			System.exit(0);
		}
		if (StdDrawModified.isKeyPressed(KeyEvent.VK_Z)) {
			move_left();
		}
		if (StdDrawModified.isKeyPressed(KeyEvent.VK_C)) {
			move_right();
		}
		if (StdDrawModified.isKeyPressed(KeyEvent.VK_B)) {
			rotate_left();
		}
		if (StdDrawModified.isKeyPressed(KeyEvent.VK_M)) {
			rotate_right();
		}
		if (StdDrawModified.isKeyPressed(KeyEvent.VK_R)) {
			reset();
		}
		if (StdDrawModified.isKeyPressed(KeyEvent.VK_SPACE)) {
			missile = new LaserProjectile(REFRESH_RATE_ms, x, angle);
			missiles.add(missile);
		}
	}

	private void reset()
	{
		game_over = false;
		total_rows_of_enemies = 5;
		if (System.currentTimeMillis() - prev_reset_time > 1000) {
			// enemies.reset();
			for (int i = 0; i < rows_of_enemies.size(); i++)
			{
				rows_of_enemies.get(i).reset(i);
			}
			level++;
			prev_reset_time = System.currentTimeMillis();
		}
	}

	private void welcome_screen() {
		StdDrawModified.clear(StdDrawModified.BLACK);
		StdDrawModified.setPenColor(StdDrawModified.YELLOW);
		StdDrawModified.text(0, 0, "Welcome to the Dark Side!");
	}

	private void game_over_screen() {
		StdDrawModified.clear(StdDrawModified.BLACK);
		StdDrawModified.setPenColor(StdDrawModified.RED);
		StdDrawModified.text(0, 0, "Game Over!");
		text_level();
	}

	private void text_level() {
		StdDrawModified.setPenColor(StdDrawModified.GREEN);
		StdDrawModified.text(-1 + 0.1, 1 - 0.05, "Level: " + level);
	}

	private void draw_all_enemies_and_lasers()
	{
		if (!game_over)
		{
			StdDrawModified.clear(StdDrawModified.DARK_GRAY);
			// draws space craft
			ship.draw_spacecraft(x, angle);
			text_level();

			// draws enemies as well, and if it is the end, then game over.
			if (it_is_the_end()) {
				game_over_screen();
				game_over = true;
			}

			// draws laser beams and checks for collisions.
			if (!missiles.isEmpty()) 
			{
				for (int j = 0; j < rows_of_enemies.size(); j++)
				{
					for (int i = 0; i < missiles.size(); i++) {

						// if there is a collision between a laser and all the enemies in a row
						if (rows_of_enemies.get(j).check_for_collision(missiles.get(i).get_laser_x(), missiles.get(i).get_laser_y()))
						{
							missiles.remove(i);
						}
					}
				}
				// draws laser beams
				for (int i = 0; i < missiles.size(); i++) 
				{
					if (!missiles.get(i).draw_laser_beam(x)) {
						missiles.remove(i);
					}
				}
			}
			for (int j = 0; j < rows_of_enemies.size(); j++)
			{
				rows_of_enemies.get(j).set_vertical_velocity((vertical_velocity));
				rows_of_enemies.get(j).set_horizontal_velocity((horizontal_velocity));
				if (rows_of_enemies.get(j).all_dead())
				{
					rows_of_enemies.remove(j);
				}
			}
			if (!rows_of_enemies.isEmpty())
			{
				if (rows_of_enemies.get(rows_of_enemies.size() - 1).check_if_starting_y_lower_than_original_y())
				{
					rows_of_enemies.add(new Enemies(total_columns_of_enemies, 1));
				}
			}
			else
			{
				rows_of_enemies.add(new Enemies(total_columns_of_enemies, rows_of_enemies.size() + 1));
			}

		}
		else
		{
			game_over_screen();
		}
	}

	public static void main(String[] args) {
		DeathStar ds = new DeathStar();
		TimerTask main_task = new TimerClass(ds);
		Timer timer = new Timer(true);

		ds.setup();
		ds.welcome_screen();

		while (!StdDrawModified.hasNextKeyTyped()) {
		}

		timer.scheduleAtFixedRate(main_task, 0, 10);
/*		while (true) {
			long now = System.currentTimeMillis();
			ds.update_foreground();
			ds.pressed_keys();
			System.out.println(System.currentTimeMillis() - now);
			
			 * if (StdDrawModified.hasNextKeyTyped()) {
			 * ds.process_key(StdDrawModified.nextKeyTyped()); }
			 
		}*/
	}

}
